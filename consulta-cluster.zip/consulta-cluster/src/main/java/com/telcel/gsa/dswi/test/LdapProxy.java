package com.telcel.gsa.dswi.test;

public class LdapProxy implements com.telcel.gsa.dswi.test.Ldap {
  private String _endpoint = null;
  private com.telcel.gsa.dswi.test.Ldap ldap = null;
  
  public LdapProxy() {
    _initLdapProxy();
  }
  
  private void _initLdapProxy() {
    try {
      ldap = (new com.telcel.gsa.dswi.test.LdapServiceLocator()).getldap();
      if (ldap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)ldap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)ldap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (ldap != null)
      ((javax.xml.rpc.Stub)ldap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.telcel.gsa.dswi.test.Ldap getLdap() {
    if (ldap == null)
      _initLdapProxy();
    return ldap;
  }
  
  public java.lang.String autenticarUsuarioApp(java.lang.String numeroEmpleado, java.lang.String password, java.lang.String idApp, java.lang.String claveApp) throws java.rmi.RemoteException{
    if (ldap == null)
      _initLdapProxy();
    return ldap.autenticarUsuarioApp(numeroEmpleado, password, idApp, claveApp);
  }
  
  public java.lang.String autenticarUsuario(java.lang.String numeroempleado, java.lang.String password) throws java.rmi.RemoteException{
    if (ldap == null)
      _initLdapProxy();
    return ldap.autenticarUsuario(numeroempleado, password);
  }
  
  
}