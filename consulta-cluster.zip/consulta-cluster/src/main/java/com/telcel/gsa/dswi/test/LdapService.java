/**
 * LdapService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.telcel.gsa.dswi.test;

public interface LdapService extends javax.xml.rpc.Service {
    public java.lang.String getldapAddress();

    public com.telcel.gsa.dswi.test.Ldap getldap() throws javax.xml.rpc.ServiceException;

    public com.telcel.gsa.dswi.test.Ldap getldap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
