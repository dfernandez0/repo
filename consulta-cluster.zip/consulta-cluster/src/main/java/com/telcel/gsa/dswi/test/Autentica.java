package com.telcel.gsa.dswi.test;

import java.rmi.RemoteException;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class for Servlet: Autentica
 *
 */
 public class Autentica extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 8017384910525786014L;

	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public Autentica() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String usuario = request.getParameter("usuario");
		String password = request.getParameter("password");
		HttpSession session = request.getSession();
		session.setAttribute("numemp", usuario);
		session.setAttribute("usuario", usuario);
		session.setAttribute("password", password);
		session.setAttribute("user", usuario);
		    
		LdapProxy nom = new LdapProxy();           
        nom.setEndpoint("http://serviciosidentidad.telcel.com:8000/ldapWeb/services/ldap");
      try {
      	  //Busca autenticar al distribuidor
             String res = nom.autenticarUsuarioApp(usuario,password,"00410204001","intraextra");
             System.out.println("Invocacion WS LDAP ****:"+res);
//             System.out.println("Usuario universal: "+res.substring(2));
             if(res.startsWith("1")){
            	   System.out.println("Exitoso");
            	   response.sendRedirect("ValusuV10");	   
               }
             else{ 
            	 response.sendRedirect(request.getContextPath()+"/Error.jsp");
             }
            	 
             System.out.println("Invocacion WS LDAP:"+res); 
             //String resultado = res.substring(0);
             //System.out.println("####"+resultado);
             
      } catch(RemoteException ex){
             ex.printStackTrace();
      }
	}   	  	    
}