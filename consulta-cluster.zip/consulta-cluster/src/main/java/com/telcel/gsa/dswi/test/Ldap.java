/**
 * Ldap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.telcel.gsa.dswi.test;

public interface Ldap extends java.rmi.Remote {
    public java.lang.String autenticarUsuarioApp(java.lang.String numeroEmpleado, java.lang.String password, java.lang.String idApp, java.lang.String claveApp) throws java.rmi.RemoteException;
    public java.lang.String autenticarUsuario(java.lang.String numeroempleado, java.lang.String password) throws java.rmi.RemoteException;
}
