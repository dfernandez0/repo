package com.telcel.consultas.cluster.dao;

import java.util.List;

import com.telcel.consultas.cluster.domain.Instancia;



public interface InstanciaDAO {

	public List<Instancia> obtenerInstancias();
	public List<Instancia> buscarInstanciaFiltrado(String parametro);
}
