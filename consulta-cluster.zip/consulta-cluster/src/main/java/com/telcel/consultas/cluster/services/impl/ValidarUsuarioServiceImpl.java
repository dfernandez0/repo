package com.telcel.consultas.cluster.services.impl;

import java.rmi.RemoteException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telcel.consultas.cluster.domain.Usuario;
import com.telcel.consultas.cluster.services.ValidarUsuarioService;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.gsa.dswi.test.LdapProxy;

@Service("validarUsuarioService")
@Component
public class ValidarUsuarioServiceImpl implements ValidarUsuarioService {
	private static Logger LOG = LoggerFactory.getLogger(ValidarUsuarioServiceImpl.class);
	
	@Override
	public Usuario validarEmpleado(Usuario credencial){
		Usuario usuario=null;
		String respuesta=this.testNumeroEmpleado(credencial);
		if(respuesta!=null){
			String[] codigoRespuesta = respuesta.split("|");
			if (codigoRespuesta != null && codigoRespuesta[0].equals("1")) {
				usuario=new Usuario();
				usuario.setUsername(credencial.getUsername());
				usuario.setPassword(credencial.getPassword());
				usuario.setUsuarioId(codigoRespuesta[1]);
				LOG.info("codigoRespuesta 0: [{}] ", codigoRespuesta[0].trim());
				LOG.info("codigoRespuesta 1: [{}] ", codigoRespuesta[1].trim());
			}
		}
		return usuario;
	}
	
	private String testNumeroEmpleado(Usuario credencial){
		LdapProxy login = new LdapProxy();
		login.setEndpoint(Constantes.ENPOINT_USER);
		String respuesta =null;
		try {
			respuesta=login.autenticarUsuario(credencial.getUsername(), credencial.getPassword());
			respuesta=respuesta.replaceAll("\n", "");
			respuesta=respuesta.replaceAll("(\n|\r)", "");
			LOG.info("Respuesta Empleado Testing: {} ", respuesta);
		} catch (RemoteException e) {
			LOG.error("Error al validar empleado", e);
		}
		String[] a = respuesta.split("]");
		for (int x=0;x<a.length;x++){
			System.out.println("valor: " + a[x]);
		}

		return respuesta;
	}
}
