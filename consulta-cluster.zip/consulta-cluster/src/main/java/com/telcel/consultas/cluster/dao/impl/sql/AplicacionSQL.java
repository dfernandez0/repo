package com.telcel.consultas.cluster.dao.impl.sql;

public interface AplicacionSQL {
	
	String OBTENER_APLICACIONES=
			"  SELECT AP.id_aplicacion," 
            + "       AP.nombre nombre_aplicacion," 
			+ " 	  AP.virtualhost,"
			+ "       AP.url_pruebas," 
			+ "       AP.descripcion," 
			+ "       AP.prioridad,"
			+ "       AP.estatus estatus_aplicacion," 
			+ "       CL.id_cluster," 
			+ "       CL.nombre nombre_cluster,"
			+ "       DM.id_dmgr," 
			+ "       DM.nombre nombre_dmgr," 
			+ "       DM.url," 
			+ "       DM.usuario," 
			+ "       DM.password,"
			+ "       DM.id_servidor" 
			+ "  FROM vi0admbd.APLICACION AP"
			+ " INNER JOIN vi0admbd.cluster CL ON CL.id_cluster = AP.id_cluster"
			+ " INNER JOIN  vi0admbd.dmgr DM ON DM.id_dmgr = CL.id_dmgr";

	
     String OBTENER_APLICACIONES_FILTRO=
    		" SELECT AP.id_aplicacion, " 
			+ "		 AP.nombre nombre_aplicacion, "
			+ "		 AP.virtualhost, "
			+ "		 AP.url_pruebas, "
			+ "		 AP.descripcion, "
			+ "		 AP.prioridad, "
			+ "	     AP.estatus estatus_aplicacion, "
			+ "		 CL.id_cluster, "
			+ "		 CL.nombre nombre_cluster, " 
			+ "		 DM.id_dmgr, " 
			+ "		 DM.nombre nombre_dmgr, "
			+ "		 DM.url, " 
			+ "		 DM.usuario, " 
			+ "		 DM.password, " 
			+ "		 DM.id_servidor "
			+ " FROM vi0admbd.APLICACION AP " 
			+ " INNER JOIN vi0admbd.cluster CL ON CL.id_cluster = AP.id_cluster "
			+ " INNER JOIN  vi0admbd.dmgr DM ON DM.id_dmgr = CL.id_dmgr " 
			+ " WHERE AP.id_aplicacion like :idAplicacion "
			+ " or AP.nombre like :nombreAplicacion "
			+ " or DM.nombre like :nombreDmgr "
			+ " or CL.nombre like :nombreCluster "; 					 
}
