package com.telcel.consultas.cluster.dao;

import java.util.List;

import com.telcel.consultas.cluster.domain.Aplicacion;

public interface  AplicacionDAO {
    List<Aplicacion> obtenerAplicaciones();
	List<Aplicacion> obtenerAplicaciones(String parametro);
}
