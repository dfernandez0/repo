package com.telcel.consultas.cluster.services;

import java.util.List;

import com.telcel.consultas.cluster.domain.Aplicacion;

public interface AplicacionService {
	List<Aplicacion> obtenerAplicaciones();
	List<Aplicacion> obtenerAplicaciones(String parametro);
}
