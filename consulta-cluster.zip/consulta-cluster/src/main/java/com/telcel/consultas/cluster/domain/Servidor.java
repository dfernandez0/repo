package com.telcel.consultas.cluster.domain;

import java.io.Serializable;

public class Servidor implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1261396899598536394L;

	private Integer idServidor;
	private String  ip;
	private String  nombre;
	private String comentarios;
	private Integer idArea;
	private Integer id_lpar;
	
	public Integer getIdServidor() {
		return idServidor;
	}
	public void setIdServidor(Integer idServidor) {
		this.idServidor = idServidor;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getComentarios() {
		return comentarios;
	}
	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}
	public Integer getIdArea() {
		return idArea;
	}
	public void setIdArea(Integer idArea) {
		this.idArea = idArea;
	}
	public Integer getId_lpar() {
		return id_lpar;
	}
	public void setId_lpar(Integer id_lpar) {
		this.id_lpar = id_lpar;
	}
	@Override
	public String toString() {
		return "Servidor [idServidor=" + idServidor + ", ip=" + ip + ", nombre=" + nombre + ", comentarios="
				+ comentarios + ", idArea=" + idArea + ", id_lpar=" + id_lpar + "]";
	}
	
	

}
