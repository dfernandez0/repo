package com.telcel.consultas.cluster.bean.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telcel.consultas.cluster.domain.Instancia;
import com.telcel.consultas.cluster.dto.AccionesDTO;
import com.telcel.consultas.cluster.services.InstanciaService;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.consultas.cluster.utils.ConsultasUtil;

@ManagedBean(name = "consultaInstanciaMB")
@ViewScoped
public class ConsultaInstanciaMB {

	private static Logger LOG = LoggerFactory.getLogger(ConsultaInstanciaMB.class);

	@ManagedProperty(value = "#{instanciaService}")
	private InstanciaService instanciaService;

	private Instancia instanciaSelect;
	private List<Instancia> listaInstancia;
	private AccionesDTO accionesDTO = new AccionesDTO();

	@PostConstruct
	public void init() {
		ConsultasUtil.validarSesionActiva();
		this.ocultarElementos(false);
		this.obtenerInstancias();
	}

	private void obtenerInstancias() {
		try {
			String texto = (String) ConsultasUtil.obtenerParametroSession(Constantes.FILTRO_INSTANCIAS);
			LOG.info("Sesion buscar [{}]", texto);
			if (texto != null && texto.trim().length() > 0) {
				this.accionesDTO.setTextoBuscar(texto);
				this.listaInstancia = this.instanciaService.buscarInstanciaFiltrado(this.accionesDTO.getTextoBuscar());
			} else {
				this.listaInstancia = this.instanciaService.obtenerInstancias();
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	public void onRowSelect(SelectEvent event) {
		if (instanciaSelect != null) {
			LOG.info("Selected {}", instanciaSelect.getIdInstancia());
		}
		this.accionesDTO.setMostrarDetalle(true);
		this.accionesDTO.setMostrarLista(false);
	}

	public void onRowUnselect(UnselectEvent event) {
		LOG.info("Inicio..........ConsultaAplicacionMB.onRowUnselect");
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
	}

	public void regresarLista() {
		LOG.info("Inicio............regresarLista");
		ConsultasUtil.retardarEvento(5);
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
		this.setInstanciaSelect(null);
	}

	public void buscarInstanciaFiltrado() {
		try {
			if (this.accionesDTO.getTextoBuscar() != null && this.accionesDTO.getTextoBuscar().trim().length() > 0) {
				LOG.info("Texto a buscar: [{}] ", this.accionesDTO.getTextoBuscar());
				this.listaInstancia = this.instanciaService.buscarInstanciaFiltrado(this.accionesDTO.getTextoBuscar());
				if (this.listaInstancia != null && this.listaInstancia.size() > 0) {
					ConsultasUtil.subirParametroSession(Constantes.FILTRO_INSTANCIAS,
							this.accionesDTO.getTextoBuscar());
					LOG.info("Registros encontrados: [{}] ", this.listaInstancia.size());
				} else {
					ConsultasUtil.subirParametroSession(Constantes.FILTRO_INSTANCIAS, null);
				}
			} else {
				this.listaInstancia = this.instanciaService.obtenerInstancias();
				ConsultasUtil.subirParametroSession(Constantes.FILTRO_INSTANCIAS, null);
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	private void ocultarElementos(boolean nuevo) {
		if (nuevo) {
			this.accionesDTO.setMostrarLista(false);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(true);
			this.accionesDTO.setMostrarEliminar(false);
		} else {
			this.accionesDTO.setMostrarLista(true);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(false);
			this.accionesDTO.setMostrarEliminar(false);
		}

	}

	public InstanciaService getInstanciaService() {
		return instanciaService;
	}

	public void setInstanciaService(InstanciaService instanciaService) {
		this.instanciaService = instanciaService;
	}

	public Instancia getInstanciaSelect() {
		return instanciaSelect;
	}

	public void setInstanciaSelect(Instancia instanciaSelect) {
		this.instanciaSelect = instanciaSelect;
	}

	public List<Instancia> getListaInstancia() {
		return listaInstancia;
	}

	public void setListaInstancia(List<Instancia> listaInstancia) {
		this.listaInstancia = listaInstancia;
	}

	public AccionesDTO getAccionesDTO() {
		return accionesDTO;
	}

	public void setAccionesDTO(AccionesDTO accionesDTO) {
		this.accionesDTO = accionesDTO;
	}
}
