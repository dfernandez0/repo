package com.telcel.consultas.cluster.services;

import com.telcel.consultas.cluster.domain.Usuario;

public interface ValidarUsuarioService {
	Usuario validarEmpleado(Usuario credencial);
}
