package com.telcel.consultas.cluster.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class CommonDAO {
	protected static Logger LOG = LoggerFactory.getLogger(CommonDAO.class);
	
	@Autowired
	@Qualifier("jdbcTemplateDB")
	protected JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("namedParameterJdbcTemplateBD")
	protected NamedParameterJdbcTemplate namedParameterJdbcTemplate;

}
