package com.telcel.consultas.cluster.dao.impl.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telcel.consultas.cluster.domain.Aplicacion;
import com.telcel.consultas.cluster.domain.Cluster;
import com.telcel.consultas.cluster.domain.Dmgr;

public class AplicacionInfoCompletaMapper implements RowMapper<Aplicacion>{

@Override
public Aplicacion mapRow(ResultSet rs, int arg1) throws SQLException {

	Aplicacion aplicacion = new Aplicacion();
		
	    aplicacion.setIdAplicacion(rs.getInt("id_aplicacion"));
        aplicacion.setNombre(rs.getString("nombre_aplicacion")!=null?rs.getString("nombre_aplicacion"):"");
        aplicacion.setVirtualhost(rs.getString("virtualhost")!=null?rs.getString("virtualhost"):"");
        aplicacion.setUrlPruebas(rs.getString("url_pruebas")!=null?rs.getString("url_pruebas"):"");      
        aplicacion.setDescripcion(rs.getString("descripcion")!=null?rs.getString("descripcion"):"");
		aplicacion.setEstatus(rs.getInt("prioridad"));
		aplicacion.setEstatus(rs.getInt("estatus_aplicacion"));
		
		Cluster cluster = new Cluster();
		cluster.setIdCluster(rs.getInt("id_cluster"));
		cluster.setNombre(rs.getString("nombre_cluster")!=null?rs.getString("nombre_cluster"):"");
		aplicacion.setCluster(cluster);
		
		Dmgr dmgr = new Dmgr(); 
		dmgr.setIdDmgr(rs.getInt("id_dmgr"));
		dmgr.setNombre(rs.getString("nombre_dmgr")!=null?rs.getString("nombre_dmgr"):"");
		dmgr.setUrl(rs.getString("url")!=null?rs.getString("url"):"");
		dmgr.setUsuario(rs.getString("usuario")!=null?rs.getString("usuario"):"");
		dmgr.setPassword(rs.getString("password")!=null?rs.getString("password"):"");
		dmgr.setIdServidor(rs.getInt("id_servidor"));
		aplicacion.setDmgr(dmgr);
	
		return aplicacion;
	}

}
