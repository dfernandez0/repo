package com.telcel.consultas.cluster.bean.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telcel.consultas.cluster.domain.Aplicacion;
import com.telcel.consultas.cluster.dto.AccionesDTO;
import com.telcel.consultas.cluster.services.AplicacionService;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.consultas.cluster.utils.ConsultasUtil;

@ManagedBean(name = "consultaAplicacionMB")
@ViewScoped
public class ConsultaAplicacionMB implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7190227731533823386L;

	private static Logger LOG = LoggerFactory.getLogger(ConsultaAplicacionMB.class);

	@ManagedProperty(value = "#{aplicacionService}")
	private AplicacionService aplicacionService;
	private Aplicacion aplicacion;
	private Aplicacion aplicacionSelect;
	private List<Aplicacion> listaAplicacion;
	private List<Aplicacion> listaAplicacionCom;
	private AccionesDTO accionesDTO = new AccionesDTO();

	@PostConstruct
	public void init() {
		ConsultasUtil.validarSesionActiva();
		this.ocultarElementos(false);
		this.obtenerAplicaciones();
	}

	private void obtenerAplicaciones() {
		try {
			String texto = (String) ConsultasUtil.obtenerParametroSession(Constantes.FILTRO_APLICACIONES);
			LOG.info("Sesion buscar [{}]", texto);
			if (texto != null && texto.trim().length() > 0) {
				this.accionesDTO.setTextoBuscar(texto);
				this.listaAplicacionCom = this.aplicacionService.obtenerAplicaciones(this.accionesDTO.getTextoBuscar());
			} else {
				this.listaAplicacionCom = this.aplicacionService.obtenerAplicaciones();
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	public void onRowSelect(SelectEvent event) {
		if (aplicacionSelect != null) {
			LOG.info("Selected {}", aplicacionSelect.getIdAplicacion());
		}
		this.accionesDTO.setMostrarDetalle(true);
		this.accionesDTO.setMostrarLista(false);
	}

	public void onRowUnselect(UnselectEvent event) {
		LOG.info("Inicio..........ConsultaAplicacionMB.onRowUnselect");
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
	}

	public void regresarLista() {
		LOG.info("Inicio............regresarLista");
		ConsultasUtil.retardarEvento(5);
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
		this.setAplicacionSelect(null);
	}

	public void buscarAplicacionFiltrado() {
		try {
			if (this.accionesDTO.getTextoBuscar() != null && this.accionesDTO.getTextoBuscar().trim().length() > 0) {
				LOG.info("Texto a buscar: [{}] ", this.accionesDTO.getTextoBuscar());
				this.listaAplicacionCom = this.aplicacionService.obtenerAplicaciones(this.accionesDTO.getTextoBuscar());
				if (this.listaAplicacionCom != null && this.listaAplicacionCom.size() > 0) {
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
							.put(Constantes.FILTRO_APLICACIONES, this.accionesDTO.getTextoBuscar());
					LOG.info("Registros encontrados: [{}] ", this.listaAplicacionCom.size());
				} else {
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
							.put(Constantes.FILTRO_APLICACIONES, null);
				}
			} else {
				this.listaAplicacionCom = this.aplicacionService.obtenerAplicaciones();
				ConsultasUtil.subirParametroSession(Constantes.FILTRO_APLICACIONES, null);
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	private void ocultarElementos(boolean nuevo) {
		if (nuevo) {
			this.accionesDTO.setMostrarLista(false);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(true);
			this.accionesDTO.setMostrarEliminar(false);
		} else {
			this.accionesDTO.setMostrarLista(true);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(false);
			this.accionesDTO.setMostrarEliminar(false);
		}

	}

	public AplicacionService getAplicacionService() {
		return aplicacionService;
	}

	public void setAplicacionService(AplicacionService aplicacionService) {
		this.aplicacionService = aplicacionService;
	}

	public Aplicacion getAplicacion() {
		return aplicacion;
	}

	public void setAplicacion(Aplicacion aplicacion) {
		this.aplicacion = aplicacion;
	}

	public List<Aplicacion> getListaAplicacion() {
		return listaAplicacion;
	}

	public void setListaAplicacion(List<Aplicacion> listaAplicacion) {
		this.listaAplicacion = listaAplicacion;
	}

	public Aplicacion getAplicacionSelect() {
		return aplicacionSelect;
	}

	public void setAplicacionSelect(Aplicacion aplicacionSelect) {
		this.aplicacionSelect = aplicacionSelect;
	}

	public List<Aplicacion> getListaAplicacionCom() {
		return listaAplicacionCom;
	}

	public void setListaAplicacionCom(List<Aplicacion> listaAplicacionCom) {
		this.listaAplicacionCom = listaAplicacionCom;
	}

	public AccionesDTO getAccionesDTO() {
		return accionesDTO;
	}

	public void setAccionesDTO(AccionesDTO accionesDTO) {
		this.accionesDTO = accionesDTO;
	}
}
