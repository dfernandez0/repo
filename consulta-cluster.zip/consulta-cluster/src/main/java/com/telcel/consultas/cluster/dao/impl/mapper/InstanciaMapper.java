package com.telcel.consultas.cluster.dao.impl.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telcel.consultas.cluster.domain.Cluster;
import com.telcel.consultas.cluster.domain.Instancia;
import com.telcel.consultas.cluster.domain.Servidor;

public class InstanciaMapper implements RowMapper<Instancia> {

	@Override
	public Instancia mapRow(ResultSet rs, int arg1) throws SQLException {

		Instancia instancia = new Instancia();
		instancia.setIdInstancia(rs.getInt("id_instancia"));
		instancia.setNombreinstan(rs.getString("nombreinstan")!=null?rs.getString("nombreinstan"):"");
		instancia.setNodo(rs.getString("nodo")!=null?rs.getString("nodo"):"");
		instancia.setPuerto(rs.getString("puerto")!=null?rs.getString("puerto"):"");
		instancia.setRutaLogs(rs.getString("ruta_logs")!=null?rs.getString("ruta_logs"):"");
		instancia.setEstatus(rs.getInt("estatus"));

		Cluster cluster = new Cluster();
		cluster.setIdCluster(rs.getInt("id_cluster"));
		cluster.setNombre(rs.getString("nombre_cluster")!=null?rs.getString("nombre_cluster"):"");
		instancia.setCluster(cluster);

		Servidor servidor = new Servidor();
		servidor.setIdServidor(rs.getInt("id_servidor"));
		servidor.setNombre(rs.getString("nombre_servidor")!=null?rs.getString("nombre_servidor"):"");
		servidor.setIp(rs.getString("ip")!=null?rs.getString("ip"):"");
		servidor.setComentarios(rs.getString("comentarios")!=null?rs.getString("comentarios"):"");
		servidor.setIdArea(rs.getInt("id_area"));
		servidor.setId_lpar(rs.getInt("id_lpar"));
		instancia.setServidor(servidor);

		return instancia;
	}

}
