package com.telcel.consultas.cluster.domain;

public class Cluster {
	
	private Integer idCluster;
	private String   nombre;
	public Integer getIdCluster() {
		return idCluster;
	}
	public void setIdCluster(Integer idCluster) {
		this.idCluster = idCluster;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Cluster [idCluster=" + idCluster + ", nombre=" + nombre + "]";
	}
	
	

}
