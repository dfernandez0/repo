package com.telcel.consultas.cluster.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.charset.StandardCharsets;

public class EncriptaUtil {
	private static Logger LOG = LoggerFactory.getLogger(EncriptaUtil.class);
	
	public static String encriptar(String texto) {

	        MessageDigest md = null;
			try {
				md = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException e) {
				LOG.error("Error: {}",e);
			}
	        byte[] hashInBytes = md.digest(texto.getBytes(StandardCharsets.UTF_8));

	        StringBuilder sb = new StringBuilder();
	        for (byte b : hashInBytes) {
	            sb.append(String.format("%02x", b));
	        }	
	        LOG.info("texto encriptado:{}",sb.toString());
	      return sb.toString();
	}
	
	
	public static String encriptarPassword(String password) {
		return DigestUtils.md5Hex(password);
	}

}