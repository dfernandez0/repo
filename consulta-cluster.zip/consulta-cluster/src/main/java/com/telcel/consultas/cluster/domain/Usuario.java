package com.telcel.consultas.cluster.domain;

import java.io.Serializable;

public class Usuario implements Serializable {
	private static final long serialVersionUID = 4625684489695569068L;
	private Integer id;
	private String perfil;
	//username = numero de empleado
	private String username;
	private String  password;
	private String  usuarioId;
	private Integer estatus;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPerfil() {
		return perfil;
	}
	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsuarioId() {
		return usuarioId;
	}
	public void setUsuarioId(String usuarioId) {
		this.usuarioId = usuarioId;
	}
	public Integer getEstatus() {
		return estatus;
	}
	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	@Override
	public String toString() {
		return "Usuario [id=" + id + ", perfil=" + perfil + ", username=" + username + ", password=" + password
				+ ", usuarioId=" + usuarioId + ", estatus=" + estatus + "]";
	}
	
	
	
}
