package com.telcel.consultas.cluster.utils;

import com.telcel.consultas.cluster.domain.Usuario;

public class ValidarFormUsuarioUtil {
	public static Integer validarFormulario(final Usuario usuario){
		Integer errores=0;
		if(usuario!=null){
			if(validarCampo(usuario.getUsername())){
				errores++;
			}
			if(validarCampo(usuario.getPerfil())){
				errores++;
			}
		} else {
			errores++;
		}
		
		return errores;
	}
	
	public static boolean validarCampo(String campo){
		boolean validar=true;
		if(campo!=null && campo.trim().length()>0){
			validar=false;
		}
		return validar;
	}
}
