package com.telcel.consultas.cluster.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telcel.consultas.cluster.dao.AplicacionDAO;
import com.telcel.consultas.cluster.domain.Aplicacion;
import com.telcel.consultas.cluster.services.AplicacionService;

@Service("aplicacionService")
@Component
public class AplicacionServiceImpl implements AplicacionService {

	@Autowired
	private AplicacionDAO aplicacionDAO;

	@Override
	public List<Aplicacion> obtenerAplicaciones() {
		return aplicacionDAO.obtenerAplicaciones();
	}
	
	@Override
	public List<Aplicacion> obtenerAplicaciones(String parametro) {
		return aplicacionDAO.obtenerAplicaciones(parametro);
	}
	

}
