package com.telcel.consultas.cluster.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telcel.consultas.cluster.dao.UsuarioDAO;
import com.telcel.consultas.cluster.domain.Usuario;
import com.telcel.consultas.cluster.services.UsuarioService;
import com.telcel.consultas.cluster.utils.EncriptaUtil;

@Service("usuarioService")
@Component
public class UsuarioServiceImpl implements UsuarioService {
	private static Logger LOG = LoggerFactory.getLogger(UsuarioServiceImpl.class);
	@Autowired
	private UsuarioDAO usuarioDAO;

	@Override
	public List<Usuario> obtenerUsuarios() {

		return usuarioDAO.obtenerUsuarios();
	}

	@Override
	public List<Usuario> buscarUsuarioFiltrado(String parametro) {

		return usuarioDAO.buscarUsuarioFiltrado(parametro);
	}

	@Override
	public void guardarUsuario(Usuario usuario) {

		usuarioDAO.guardarUsuario(usuario);
	}

	@Override
	public void eliminarUsuario(Integer idUsuario) {

		usuarioDAO.eliminarUsuario(idUsuario);
	}

	public Usuario validarUsuario(Usuario usuario) {
		usuario.setPassword(EncriptaUtil.encriptarPassword(usuario.getPassword()));
		LOG.info("Password: [{}]", usuario.getPassword());
		return usuarioDAO.validarUsuario(usuario);
	}

}
