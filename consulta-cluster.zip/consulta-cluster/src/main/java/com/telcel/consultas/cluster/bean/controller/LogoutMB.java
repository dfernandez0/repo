package com.telcel.consultas.cluster.bean.controller;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telcel.consultas.cluster.domain.Usuario;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.consultas.cluster.utils.ConsultasUtil;

@ManagedBean(name = "logoutMB")
@ViewScoped
public class LogoutMB implements Serializable{
	private static final long serialVersionUID = 3665782074939403987L;
	
	private static Logger LOG = LoggerFactory.getLogger(LoginMB.class);
	
	private Usuario usuarioActivo;
	
	@PostConstruct
	public void init() {
		Integer logeado = (Integer) ConsultasUtil.obtenerParametroSession(Constantes.SESSION_ACTIVO);
		if (logeado != null && logeado>0) {
			usuarioActivo=(Usuario) ConsultasUtil.obtenerParametroSession(Constantes.USUARIO_ACTIVO);
		}
	}
	
	public void cerrarSesion(){
		LOG.info("Cerrar sesion");
		ConsultasUtil.retardarEvento(800);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().clear();
	    FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	    ConsultasUtil.redirigirPagina(Constantes.FORM_LOGIN);
	}

	public Usuario getUsuarioActivo() {
		return usuarioActivo;
	}

	public void setUsuarioActivo(Usuario usuarioActivo) {
		this.usuarioActivo = usuarioActivo;
	}
}
