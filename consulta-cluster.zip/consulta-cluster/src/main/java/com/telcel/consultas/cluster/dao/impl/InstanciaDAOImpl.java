package com.telcel.consultas.cluster.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.telcel.consultas.cluster.common.CommonDAO;
import com.telcel.consultas.cluster.dao.InstanciaDAO;
import com.telcel.consultas.cluster.dao.impl.mapper.InstanciaMapper;
import com.telcel.consultas.cluster.dao.impl.sql.InstanciasSQL;
import com.telcel.consultas.cluster.domain.Instancia;

@Repository("InstanciaDAO")
public class InstanciaDAOImpl extends CommonDAO implements InstanciaDAO {

	public InstanciaDAOImpl() {

	}

	@Override
	public List<Instancia> obtenerInstancias() {
		List<Instancia> listInstancia = null;

		listInstancia = jdbcTemplate.query(InstanciasSQL.OBTENER_INSTANCIAS, new Object[] {}, new InstanciaMapper());
		return listInstancia;
	}

	@Override
	public List<Instancia> buscarInstanciaFiltrado(String parametro) {
		List<Instancia> listCluster = null;

		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		// Si la condicion es un like en el Query debe concatenarse el simbolo
		// de %
		namedParameters.addValue("nombreInstancia", "%" + parametro + "%");
		namedParameters.addValue("nombreCluster", "%" + parametro + "%");
		namedParameters.addValue("nombreServidor", "%" + parametro + "%");
		namedParameters.addValue("ip", "%" + parametro + "%");
		namedParameters.addValue("puerto", "%" + parametro + "%");
		namedParameters.addValue("estatus", "%" + parametro + "%");

		listCluster = namedParameterJdbcTemplate.query(InstanciasSQL.OBTENER_INSTANCIA_FILTRO, namedParameters,
				new InstanciaMapper());
		return listCluster;
	}
}
