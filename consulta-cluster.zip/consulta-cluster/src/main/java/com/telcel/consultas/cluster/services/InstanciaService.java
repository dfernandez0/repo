package com.telcel.consultas.cluster.services;

import java.util.List;

import com.telcel.consultas.cluster.domain.Instancia;

public interface InstanciaService {

	
	public List<Instancia> obtenerInstancias ();
	public List<Instancia> buscarInstanciaFiltrado(String parametro);
}
