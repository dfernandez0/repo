package com.telcel.consultas.cluster.dao.impl;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.telcel.consultas.cluster.common.CommonDAO;
import com.telcel.consultas.cluster.dao.UsuarioDAO;
import com.telcel.consultas.cluster.dao.impl.mapper.UsuarioMapper;
import com.telcel.consultas.cluster.dao.impl.sql.UsuariosSQL;
import com.telcel.consultas.cluster.domain.Usuario;

@Repository("usuarioDAO")
public class UsuarioDAOImpl extends CommonDAO implements UsuarioDAO {

	@Override
	public List<Usuario> obtenerUsuarios() {
		List<Usuario> listaUsuarios = null;
		listaUsuarios = jdbcTemplate.query(UsuariosSQL.OBTENER_USUARIOS, new Object[] {}, new UsuarioMapper());
		return listaUsuarios;
	}

	@Override
	public List<Usuario> buscarUsuarioFiltrado(String parametro) {
		List<Usuario> listaUsuarios = null;
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		// Si la condicion es un like en el Query debe concatenarse el simbolo
		// de %
		namedParameters.addValue("id", "%" + parametro + "%");
		namedParameters.addValue("perfil", "%" + parametro + "%");
		namedParameters.addValue("username", "%" + parametro + "%");

		listaUsuarios = namedParameterJdbcTemplate.query(UsuariosSQL.OBTENER_USUARIO_FILTRO, namedParameters,
				new UsuarioMapper());
		return listaUsuarios;
	}

	@Override
	public void guardarUsuario(Usuario usuario) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		// Si la condicion es un like en el Query debe concatenarse el simbolo
		// de %
		LOG.error("guardarUsuario EN DAO");
		LOG.info("Usuario {}", usuario.toString());
		if (usuario != null) {

			namedParameters.addValue("perfil", usuario.getPerfil());
			namedParameters.addValue("username", usuario.getUsername());
			namedParameters.addValue("usuarioId", usuario.getUsuarioId());
			namedParameters.addValue("estatus", 1);

			if (usuario.getId() != null && usuario.getId() > 0) {
				namedParameters.addValue("id", usuario.getId());
				namedParameterJdbcTemplate.update(UsuariosSQL.MODIFICAR_USUARIO, namedParameters);
			} else {
				namedParameterJdbcTemplate.update(UsuariosSQL.GUARDAR_USUARIO, namedParameters);
			}

		}
	}

	@Override
	public void eliminarUsuario(Integer idUsuario) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		// Si la condicion es un like en el Query debe concatenarse el simbolo
		// de %
		if (idUsuario != null && idUsuario > 0) {
			namedParameters.addValue("idUsuario", idUsuario);
			namedParameterJdbcTemplate.update(UsuariosSQL.ELIMINAR_USUARIO, namedParameters);
		}

	}

	@Override
	public Usuario validarUsuario(Usuario usuario) {
		Usuario usuarioValidado = null;
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		// Si la condicion es un like en el Query debe concatenarse el simbolo
		// de %
		namedParameters.addValue("username", usuario.getUsername());
		String sql = "SELECT U.* FROM vi0admbd.usuarios_validos U WHERE U.numero_empleado=? AND U.estatus=1";
		try {
			usuarioValidado = jdbcTemplate.queryForObject(sql,
					new Object[] { usuario.getUsername() }, new UsuarioMapper());
		} catch (DataAccessException e) {
			LOG.error("no se encontraron los datos del usuario {}", usuario.getUsername());
		}

		return usuarioValidado;
	}
}
