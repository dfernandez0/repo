package com.telcel.consultas.cluster.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telcel.consultas.cluster.dao.ClusterDAO;
import com.telcel.consultas.cluster.domain.Aplicacion;
import com.telcel.consultas.cluster.services.ClusterService;

@Service("clusterService")
@Component
public class ClusterServiceImpl implements ClusterService {
	@Autowired
	private ClusterDAO clusterService;

	@Override
	public List<Aplicacion> obtenerClusters() {
		return clusterService.obtenerClusters();
	}

	@Override
	public List<Aplicacion> buscarClusterFiltrado(String parametro) {
		return clusterService.buscarClusterFiltrado(parametro);
	}

}
