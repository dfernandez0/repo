package com.telcel.consultas.cluster.dao.impl.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telcel.consultas.cluster.domain.Usuario;

public class UsuarioMapper implements RowMapper<Usuario> {

	@Override
	public Usuario mapRow(ResultSet rs, int rowNum) throws SQLException {
		Usuario usuario = new Usuario();

		usuario.setId(rs.getInt("id"));
		usuario.setUsername(rs.getString("numero_empleado"));
		usuario.setPerfil(rs.getString("perfil"));
		usuario.setUsuarioId(rs.getString("usuario_id"));
		usuario.setEstatus(rs.getInt("estatus"));
		return usuario;
	}

}
