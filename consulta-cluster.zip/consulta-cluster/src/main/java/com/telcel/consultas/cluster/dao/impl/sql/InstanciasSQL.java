package com.telcel.consultas.cluster.dao.impl.sql;

public interface InstanciasSQL {
	String OBTENER_INSTANCIAS = 
   		 " SELECT I.id_instancia, "
   		 +"	     I.nombreinstan,  "
   		 +"	     I.nodo,          "
   		 +"      I.puerto,        "
   		 +"      I.ruta_logs,     "
   		 +"      I.estatus,       "
   		 +"      C.id_cluster,    "
   		 +"      C.nombre nombre_cluster, "
   		 +"      S.id_servidor,   "
   		 +"      S.nombre nombre_servidor,"
   		 +"      s.ip,            "
   		 +"      S.comentarios,   "
   		 +"      S.id_area,       "
   		 +"      S.id_lpar        "
   		 +" FROM vi0admbd.instancia I "
   		 +"	INNER JOIN  vi0admbd.servidor S ON I.id_servidor = S.id_servidor " 
   		 +"	INNER JOIN  vi0admbd.cluster C ON I.id_cluster = C.id_cluster ";
	
	String OBTENER_INSTANCIA_FILTRO=
   		 " SELECT I.id_instancia, "
            +"       I.nombreinstan, "
   		 	+"       I.nodo, "
            +"       I.puerto, "
   		 	+"       I.ruta_logs, "
            +"       I.estatus, "
   		 	+"       C.id_cluster, "
            +"       C.nombre nombre_cluster, "
   		 	+"       S.id_servidor, "
            +"       S.nombre nombre_servidor, "
   		 	+"       s.ip, "
            +"       S.comentarios, "
   		 	+"       S.id_area, "
            +"       S.id_lpar "
   		 	+" FROM vi0admbd.instancia I, "
            +"     vi0admbd.servidor S, "
   		 	+"     vi0admbd.cluster C  "
            +" WHERE I.id_servidor=S.id_servidor "
   		 	+"  AND I.id_cluster = C.id_cluster  "
            +"  AND  (I.nombreinstan LIKE :nombreInstancia " 
   		 	+"        OR C.nombre LIKE :nombreCluster "
   		 	+"        OR S.nombre LIKE :nombreServidor "
   		 	+"        OR S.IP LIKE :ip "
   		 	+"        OR I.puerto  LIKE :puerto "
   		 	+"        OR I.estatus LIKE :estatus) ";
}
