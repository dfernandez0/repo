package com.telcel.consultas.cluster.utils;

public interface Constantes  {
	 String ENPOINT_USER ="http://serviciosidentidad.telcel.com:8000/ldapWeb/services/ldap";
	 String LISTA_APLICACION = "listaAplicacion.jsf";
	 String FORM_LOGIN = "index.jsf";
	 String FILTRO_USUARIOS="buscarUsuarios";
	 String FILTRO_APLICACIONES="buscarAplicaciones";
	 String FILTRO_INSTANCIAS="buscarInstancias";
	 String FILTRO_CLUSTER="buscarCluster";
	 String USUARIO_ACTIVO="user";
	 String SESSION_ACTIVO="logeo";
}
