package com.telcel.consultas.cluster.dao.impl.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telcel.consultas.cluster.domain.Aplicacion;
import com.telcel.consultas.cluster.domain.Cluster;
import com.telcel.consultas.cluster.domain.Dmgr;

public class ClusterMapper implements RowMapper<Aplicacion>{

@Override
public Aplicacion mapRow(ResultSet rs, int arg1) throws SQLException {

	Aplicacion aplicacion = new Aplicacion();
		
	    Cluster cluster = new Cluster();
		cluster.setIdCluster(rs.getInt("id_cluster"));
		cluster.setNombre(rs.getString("nombre_cluster")!=null?rs.getString("nombre_cluster"):"");
		aplicacion.setCluster(cluster);
		
		Dmgr dmgr = new Dmgr(); 
		dmgr.setIdDmgr(rs.getInt("id_dmgr"));
		dmgr.setNombre(rs.getString("nombre_dmgr")!=null?rs.getString("nombre_dmgr"):"");
		dmgr.setUrl(rs.getString("url")!=null?rs.getString("url"):"");
		dmgr.setUsuario(rs.getString("usuario")!=null?rs.getString("usuario"):"");
		dmgr.setPassword(rs.getString("password")!=null?rs.getString("password"):"");
		dmgr.setIdServidor(rs.getInt("id_servidor"));
		aplicacion.setDmgr(dmgr);
	
		return aplicacion;
	}

}
