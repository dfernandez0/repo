package com.telcel.consultas.cluster.bean.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telcel.consultas.cluster.domain.Aplicacion;
import com.telcel.consultas.cluster.dto.AccionesDTO;
import com.telcel.consultas.cluster.services.ClusterService;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.consultas.cluster.utils.ConsultasUtil;

@ManagedBean(name = "consultaClusterMB")
@ViewScoped
public class ConsultaClusterMB {

	private static Logger LOG = LoggerFactory.getLogger(ConsultaClusterMB.class);

	@ManagedProperty(value = "#{clusterService}")
	private ClusterService clusterService;
	private Aplicacion aplicacion;
	private Aplicacion clusterSelect;
	private List<Aplicacion> listaCluster;
	private AccionesDTO accionesDTO = new AccionesDTO();

	@PostConstruct
	public void init() {
		ConsultasUtil.validarSesionActiva();
		this.ocultarElementos(false);
		this.obtenerClusters();
	}

	private void obtenerClusters() {
		try {
			String texto = (String) ConsultasUtil.obtenerParametroSession(Constantes.FILTRO_CLUSTER);
			LOG.info("Sesion buscar [{}]", texto);
			if (texto != null && texto.trim().length() > 0) {
				this.accionesDTO.setTextoBuscar(texto);
				this.listaCluster = this.clusterService.buscarClusterFiltrado(this.accionesDTO.getTextoBuscar());
			} else {
				this.listaCluster = this.clusterService.obtenerClusters();
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	public void onRowSelect(SelectEvent event) {
		if (clusterSelect != null) {
			LOG.info("Selected {}", clusterSelect.getIdAplicacion());
		}
		this.accionesDTO.setMostrarDetalle(true);
		this.accionesDTO.setMostrarLista(false);
	}

	public void onRowUnselect(UnselectEvent event) {
		LOG.info("Inicio..........ConsultaAplicacionMB.onRowUnselect");
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
	}

	public void regresarLista() {
		LOG.info("Inicio............regresarLista");
		ConsultasUtil.retardarEvento(5);
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
		this.setClusterSelect(null);
	}

	public void buscarClusterFiltrado() {
		try {
			if (this.accionesDTO.getTextoBuscar() != null && this.accionesDTO.getTextoBuscar().trim().length() > 0) {
				LOG.info("Texto a buscar: [{}] ", this.accionesDTO.getTextoBuscar());
				this.listaCluster = this.clusterService.buscarClusterFiltrado(this.accionesDTO.getTextoBuscar());
				if (this.listaCluster != null && this.listaCluster.size() > 0) {
					ConsultasUtil.subirParametroSession(Constantes.FILTRO_CLUSTER, this.accionesDTO.getTextoBuscar());
					LOG.info("Registros encontrados: [{}] ", this.listaCluster.size());
				} else {
					ConsultasUtil.subirParametroSession(Constantes.FILTRO_CLUSTER, null);
				}
			} else {
				this.listaCluster = this.clusterService.obtenerClusters();
				ConsultasUtil.subirParametroSession(Constantes.FILTRO_CLUSTER, null);
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	private void ocultarElementos(boolean nuevo) {
		if (nuevo) {
			this.accionesDTO.setMostrarLista(false);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(true);
			this.accionesDTO.setMostrarEliminar(false);
		} else {
			this.accionesDTO.setMostrarLista(true);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(false);
			this.accionesDTO.setMostrarEliminar(false);
		}

	}

	public ClusterService getclusterService() {
		return clusterService;
	}

	public void setclusterService(ClusterService clusterService) {
		this.clusterService = clusterService;
	}

	public Aplicacion getAplicacion() {
		return aplicacion;
	}

	public void setAplicacion(Aplicacion aplicacion) {
		this.aplicacion = aplicacion;
	}

	public ClusterService getClusterService() {
		return clusterService;
	}

	public void setClusterService(ClusterService clusterService) {
		this.clusterService = clusterService;
	}

	public Aplicacion getClusterSelect() {
		return clusterSelect;
	}

	public void setClusterSelect(Aplicacion clusterSelect) {
		this.clusterSelect = clusterSelect;
	}

	public List<Aplicacion> getListaCluster() {
		return listaCluster;
	}

	public void setListaCluster(List<Aplicacion> listaCluster) {
		this.listaCluster = listaCluster;
	}

	public List<Aplicacion> getlistaCluster() {
		return listaCluster;
	}

	public void setlistaCluster(List<Aplicacion> listaCluster) {
		this.listaCluster = listaCluster;
	}

	public AccionesDTO getAccionesDTO() {
		return accionesDTO;
	}

	public void setAccionesDTO(AccionesDTO accionesDTO) {
		this.accionesDTO = accionesDTO;
	}
}
