package com.telcel.consultas.cluster.domain;

import java.io.Serializable;

public class Dmgr implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4651787363784716973L;
	
	private Integer idDmgr;
	private String nombre;
	private String url;
	private String usuario;
	private String password;
	private Integer idServidor;
	public Integer getIdDmgr() {
		return idDmgr;
	}
	public void setIdDmgr(Integer idDmgr) {
		this.idDmgr = idDmgr;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getIdServidor() {
		return idServidor;
	}
	public void setIdServidor(Integer idServidor) {
		this.idServidor = idServidor;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Dmgr [idDmgr=" + idDmgr + ", nombre=" + nombre + ", url=" + url + ", usuario=" + usuario + ", password="
				+ password + ", idServidor=" + idServidor + "]";
	}
	
	

}
