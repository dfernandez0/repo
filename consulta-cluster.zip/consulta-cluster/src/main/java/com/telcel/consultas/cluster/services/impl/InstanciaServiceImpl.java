package com.telcel.consultas.cluster.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telcel.consultas.cluster.dao.InstanciaDAO;
import com.telcel.consultas.cluster.domain.Instancia;
import com.telcel.consultas.cluster.services.InstanciaService;

@Service("instanciaService")
@Component
public class InstanciaServiceImpl implements InstanciaService {

	@Autowired
	private InstanciaDAO instanciaDAO;

	@Override
	public List<Instancia> obtenerInstancias() {
		return instanciaDAO.obtenerInstancias();
	}

	@Override
	public List<Instancia> buscarInstanciaFiltrado(String parametro) {
		return instanciaDAO.buscarInstanciaFiltrado(parametro);
	}
}
