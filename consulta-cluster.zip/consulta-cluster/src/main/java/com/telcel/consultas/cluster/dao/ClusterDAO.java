package com.telcel.consultas.cluster.dao;

import java.util.List;
import com.telcel.consultas.cluster.domain.Aplicacion;

public interface ClusterDAO {
	
	public List<Aplicacion> obtenerClusters();
	public List<Aplicacion> buscarClusterFiltrado(String parametro);

}
