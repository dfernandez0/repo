package com.telcel.consultas.cluster.bean.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telcel.consultas.cluster.domain.Usuario;
import com.telcel.consultas.cluster.dto.AccionesDTO;
import com.telcel.consultas.cluster.services.UsuarioService;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.consultas.cluster.utils.ConsultasUtil;
import com.telcel.consultas.cluster.utils.MensajesUtil;
import com.telcel.consultas.cluster.utils.ValidarFormUsuarioUtil;

@ManagedBean(name = "usuariosMB")
@ViewScoped
public class UsuariosMB {

	private static Logger LOG = LoggerFactory.getLogger(UsuariosMB.class);

	@ManagedProperty(value = "#{usuarioService}")
	private UsuarioService usuarioService;
	private Usuario usuarioSelect;
	private Usuario usuario;
	private List<Usuario> listaUsuarios;
	private AccionesDTO accionesDTO = new AccionesDTO();

	@PostConstruct
	public void init() {
		ConsultasUtil.validarSesionActiva();
		this.ocultarElementos(false);
		this.obtenerUsuarios();
	}

	private void obtenerUsuarios() {
		try {
			String texto = (String) ConsultasUtil.obtenerParametroSession(Constantes.FILTRO_USUARIOS);
			LOG.info("Sesion buscar [{}]", texto);
			if (texto != null && texto.trim().length() > 0) {
				this.accionesDTO.setTextoBuscar(texto);
				this.listaUsuarios = this.usuarioService.buscarUsuarioFiltrado(accionesDTO.getTextoBuscar());
			} else {
				this.listaUsuarios = this.usuarioService.obtenerUsuarios();
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}
	public void regresarLista() {
		LOG.info("Inicio............regresarLista");
		ConsultasUtil.retardarEvento(5);
		this.accionesDTO.setMostrarDetalle(false);
		this.accionesDTO.setMostrarLista(true);
		this.setUsuarioSelect(null);
	}

	public void buscarUsuarioFiltrado() {
		try {
			if (this.accionesDTO.getTextoBuscar() != null && this.accionesDTO.getTextoBuscar().trim().length() > 0) {
				LOG.info("Texto a buscar: [{}] ", this.accionesDTO.getTextoBuscar());
				this.listaUsuarios = this.usuarioService.buscarUsuarioFiltrado(this.accionesDTO.getTextoBuscar());
				if (this.listaUsuarios != null && this.listaUsuarios.size() > 0) {
					ConsultasUtil.subirParametroSession(Constantes.FILTRO_USUARIOS, this.accionesDTO.getTextoBuscar());
					LOG.info("Registros encontrados: [{}] ", this.listaUsuarios.size());
				} else {
					ConsultasUtil.subirParametroSession(Constantes.FILTRO_USUARIOS, "");
				}
			} else {
				this.listaUsuarios = this.usuarioService.obtenerUsuarios();
				ConsultasUtil.subirParametroSession(Constantes.FILTRO_USUARIOS, "");
			}
		} catch (Exception e) {
			LOG.error("Error al cargar lista", e);
		}
	}

	private void ocultarElementos(boolean nuevo) {
		if (nuevo) {
			this.accionesDTO.setMostrarLista(false);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(true);
			this.accionesDTO.setMostrarEliminar(false);
		} else {
			this.accionesDTO.setMostrarLista(true);
			this.accionesDTO.setMostrarDetalle(false);
			this.accionesDTO.setMostrarNuevo(false);
			this.accionesDTO.setMostrarEliminar(false);
		}

	}

	public void mostrarFormulario() {
		usuario = new Usuario();
		this.ocultarElementos(true);
		ConsultasUtil.retardarEvento(5);
	}

	public void mostrarFormularioEdicion() {
		this.ocultarElementos(true);
		ConsultasUtil.retardarEvento(5);
	}
	
	public void mostrarDetalle(){
		this.accionesDTO.setMostrarDetalle(true);
		this.accionesDTO.setMostrarLista(false);
		this.accionesDTO.setMostrarNuevo(false);
	}

	public void guardarUsuario() {
		LOG.error("guardarUsuario");
		if (ValidarFormUsuarioUtil.validarFormulario(this.usuario) == 0) {
			usuarioService.guardarUsuario(usuario);
			this.obtenerUsuarios();
			if (usuario.getId() != null && usuario.getId() > 0) {
				MensajesUtil.mensajeInfo("El número de empleado " + usuario.getUsername() + " se modificó con exito.");
			} else {
				MensajesUtil.mensajeInfo("El número de empleado " + usuario.getUsername() + " se agrego con exito.");
			}
			this.ocultarElementos(false);
		} else {
			LOG.error("Mostrar mensaje de error");
			MensajesUtil.mensajeError("Campos vacios");
		}
	}

	public void eliminarUsuario() {
		if (usuario != null && usuario.getId() != null) {
			usuarioService.eliminarUsuario(usuario.getId());
			this.obtenerUsuarios();
			MensajesUtil.mensajeInfo("El número de empleado " + usuario.getUsername() + " se eliminó con exito.");
		}
	}

	public void cancelarEliminar() {
		usuario = new Usuario();
		ConsultasUtil.retardarEvento(20);
	}

	public void cancelar() {
		usuario = new Usuario();
		this.ocultarElementos(false);
		ConsultasUtil.retardarEvento(25);
	}

	public UsuarioService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}

	public Usuario getUsuarioSelect() {
		return usuarioSelect;
	}

	public void setUsuarioSelect(Usuario usuarioSelect) {
		this.usuarioSelect = usuarioSelect;
	}

	public List<Usuario> getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(List<Usuario> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public AccionesDTO getAccionesDTO() {
		return accionesDTO;
	}

	public void setAccionesDTO(AccionesDTO accionesDTO) {
		this.accionesDTO = accionesDTO;
	}

}
