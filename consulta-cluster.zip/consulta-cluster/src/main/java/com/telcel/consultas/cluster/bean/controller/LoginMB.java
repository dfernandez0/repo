package com.telcel.consultas.cluster.bean.controller;

import java.io.Serializable;
import java.rmi.RemoteException;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telcel.consultas.cluster.domain.Usuario;
import com.telcel.consultas.cluster.services.UsuarioService;
import com.telcel.consultas.cluster.utils.Constantes;
import com.telcel.consultas.cluster.utils.ConsultasUtil;
import com.telcel.consultas.cluster.utils.MensajesUtil;
import com.telcel.gsa.dswi.test.LdapProxy;

@ManagedBean(name = "loginMB")
@ViewScoped
public class LoginMB implements Serializable {
	private static Logger LOG = LoggerFactory.getLogger(LoginMB.class);
	private static final long serialVersionUID = -1448324297694959328L;

	private Usuario credencial;
	
	@ManagedProperty(value = "#{usuarioService}")
	private UsuarioService usuarioService;

	@PostConstruct
	public void init() {
		credencial=new Usuario();
		Integer logeado = (Integer) ConsultasUtil.obtenerParametroSession(Constantes.SESSION_ACTIVO);
		if (logeado != null && logeado>0) {
			ConsultasUtil.redirigirPagina(Constantes.LISTA_APLICACION);
		}
	}

	public void validarUsuario() {
		LOG.info("Crear login");
		String respuesta = null;
		String[] codigoRespuesta = null;

		LdapProxy login = new LdapProxy();
		try {
			login.setEndpoint(Constantes.ENPOINT_USER);
			respuesta = login.autenticarUsuario(this.getCredencial().getUsername(), this.getCredencial().getPassword());
			LOG.info("Respuesta Login: [{}] ", respuesta);
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		if (respuesta != null) {
			codigoRespuesta = respuesta.split("|");
		}

		Integer logeado = 0;
		if (codigoRespuesta != null && codigoRespuesta[0].equals("1")) {
			
			Usuario usuarioValida = usuarioService.validarUsuario(this.credencial);
			
			if(usuarioValida!=null && usuarioValida.getId()!=null){
				logeado = 1;
				MensajesUtil.mensajeInfo("Bienvenido " + this.getCredencial().getUsername());
				ConsultasUtil.subirParametroSession(Constantes.SESSION_ACTIVO, logeado);
				ConsultasUtil.subirParametroSession(Constantes.USUARIO_ACTIVO, this.getCredencial());
				ConsultasUtil.redirigirPagina(Constantes.LISTA_APLICACION);
			}else{
				MensajesUtil.mensajeWarn("El número de empleado "+credencial.getUsername()+" no tiene permisos para ver esta aplicación");
			} 
			
		} else {
			MensajesUtil.mensajeWarn("Credenciales inválidas");
		}
		ConsultasUtil.retardarEvento(800);
	}

	public Usuario getCredencial() {
		return credencial;
	}

	public void setCredencial(Usuario credencial) {
		this.credencial = credencial;
	}

	public UsuarioService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}
}
