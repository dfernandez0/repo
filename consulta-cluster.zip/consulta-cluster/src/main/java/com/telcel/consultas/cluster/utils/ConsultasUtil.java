package com.telcel.consultas.cluster.utils;

import java.io.IOException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConsultasUtil {
	private static Logger LOG = LoggerFactory.getLogger(ConsultasUtil.class);
	public static void mostrarDialog(String nombre){
		RequestContext context = RequestContext.getCurrentInstance();
        context.execute(nombre + ".show();");
	}
	
	public static void ocultarDialog(String nombre){
		RequestContext context = RequestContext.getCurrentInstance();
        context.execute(nombre + ".hide();");
	}
	
	public static void redirigirPagina(String url){
        
        FacesContext fc = FacesContext.getCurrentInstance();
        ExternalContext ec = fc.getExternalContext();
        try {
            ec.redirect(url);
	    } catch (IOException ex) {
	      LOG.error("Error",ex);  
	    }
	}
	
	public static void subirParametroSession(String nombreParametro,Object valor){
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(nombreParametro,valor);	
	}
	
	public static Object obtenerParametroSession(String nombreParametro){
		return FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(nombreParametro);	
	}
	
	public static void retardarEvento(Integer milisegundos){
		try {
			Thread.sleep(milisegundos);
		} catch (InterruptedException e) {
			LOG.info("Error Thread {}", e.getMessage());
		}
	}
	
	public static void validarSesionActiva(){
		Integer logeado = (Integer) ConsultasUtil.obtenerParametroSession(Constantes.SESSION_ACTIVO);
		if (logeado==null) {
			ConsultasUtil.redirigirPagina(Constantes.FORM_LOGIN);
		} else if(logeado.equals(0)){
			ConsultasUtil.redirigirPagina(Constantes.FORM_LOGIN);
		}
	}
	
}
