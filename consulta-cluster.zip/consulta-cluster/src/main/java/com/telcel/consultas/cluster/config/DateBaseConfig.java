package com.telcel.consultas.cluster.config;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableScheduling
@EnableAsync
@ComponentScan(basePackages = {"com.telcel"}, excludeFilters = { @ComponentScan.Filter(Configuration.class) })
@EnableTransactionManagement
@EnableMBeanExport
@EnableWebMvc
@PropertySource(value = {"classpath:application.properties"})
public class DateBaseConfig {
	@Autowired
	private Environment environment;
	private static Logger LOG = LoggerFactory.getLogger(DateBaseConfig.class);

	@Bean (name = "dsConexion")
	public DataSource mysqlServerDataSource() {
		LOG.info("Configuracion de conexion a base de datos");
		/*
		DataSource dataSource=null;
		try{
			Context initialContext = new InitialContext();
			dataSource = (DataSource)initialContext.lookup(environment.getRequiredProperty("datasource.context"));
		}catch(NamingException ne){
			LOG.error("Error al crear la conexion jdni ", ne);
		}
		*/
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
		dataSource.setUrl(environment.getRequiredProperty("jdbc.url"));
		dataSource.setUsername(environment.getRequiredProperty("jdbc.username"));
		dataSource.setPassword(environment.getRequiredProperty("jdbc.password"));
		return dataSource;
	}

	@Bean(name = "jdbcTemplateDB")
	public JdbcTemplate jdbcConexion() {
		return new JdbcTemplate(this.mysqlServerDataSource());
	}
	
	@Bean(name = "namedParameterJdbcTemplateBD")
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate() {
	    return new NamedParameterJdbcTemplate(this.mysqlServerDataSource());
	}
}
