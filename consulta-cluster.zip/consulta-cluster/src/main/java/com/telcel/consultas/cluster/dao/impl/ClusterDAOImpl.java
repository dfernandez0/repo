package com.telcel.consultas.cluster.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.telcel.consultas.cluster.common.CommonDAO;
import com.telcel.consultas.cluster.dao.ClusterDAO;
import com.telcel.consultas.cluster.dao.impl.mapper.ClusterMapper;
import com.telcel.consultas.cluster.dao.impl.sql.ClusterSQL;
import com.telcel.consultas.cluster.domain.Aplicacion;

@Repository("clusterDAO")
public class ClusterDAOImpl extends CommonDAO implements ClusterDAO {

	public ClusterDAOImpl() {

	}

	@Override
	public List<Aplicacion> obtenerClusters() {
		List<Aplicacion> listCluster = null;
		listCluster = jdbcTemplate.query(ClusterSQL.OBTENER_CLUSTERS, new Object[] {}, new ClusterMapper());
		return listCluster;
	}

	@Override
	public List<Aplicacion> buscarClusterFiltrado(String parametro) {
		List<Aplicacion> listCluster = null;

		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		// Si la condicion es un like en el Query debe concatenarse el simbolo
		// de %
		namedParameters.addValue("nombreDmgr", "%" + parametro + "%");
		namedParameters.addValue("nombreCluster", "%" + parametro + "%");

		listCluster = namedParameterJdbcTemplate.query(ClusterSQL.OBTENER_CLUSTERS_FILTRO, namedParameters,
				new ClusterMapper());
		return listCluster;
	}

}
