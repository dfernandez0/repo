package com.telcel.consultas.cluster.services;

import java.util.List;

import com.telcel.consultas.cluster.domain.Aplicacion;

public interface ClusterService {

	public List<Aplicacion> obtenerClusters();
	public List<Aplicacion> buscarClusterFiltrado(String parametro);
}
