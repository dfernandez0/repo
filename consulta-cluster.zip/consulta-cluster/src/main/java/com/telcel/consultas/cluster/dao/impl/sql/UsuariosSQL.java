package com.telcel.consultas.cluster.dao.impl.sql;

public interface UsuariosSQL {
	String OBTENER_USUARIOS =  " SELECT U.id,  "+ 
			"        U.perfil, "+ 
			"        U.numero_empleado, "+
			"        U.usuario_id, "+
			"        U.estatus "+
			" FROM vi0admbd.usuarios_validos U";
	
	String OBTENER_USUARIO_FILTRO = "SELECT U.id, " +
    		"        U.perfil, "+ 
			"        U.numero_empleado, "+
			"        U.usuario_id, "+
			"        U.estatus "+
			" FROM vi0admbd.usuarios_validos U "+
			" where U.id LIKE :id "+  
			"  or U.perfil LIKE :perfil "+
			"  or u.numero_empleado like :username"; 
	
	String GUARDAR_USUARIO = " INSERT INTO vi0admbd.usuarios_validos "+
            " (perfil, numero_empleado, usuario_id, estatus) "+
            " VALUES(:perfil,:username,:usuarioId,:estatus) ";
	
	String ELIMINAR_USUARIO = " DELETE FROM vi0admbd.usuarios_validos" +
             " WHERE id=:idUsuario ";
	
	String MODIFICAR_USUARIO = " UPDATE vi0admbd.usuarios_validos "+
			" SET perfil=:perfil, numero_empleado=:username, usuario_id=:usuarioId, estatus=:estatus "+
			" WHERE id=:id";
	
	String VALIDA_USUARIO = " SELECT U.* FROM vi0admbd.usuarios_validos U" +
            " WHERE U.numero_empleado=:username "+
            " AND U.estatus=1";
}
