package com.telcel.consultas.cluster.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.telcel.consultas.cluster.common.CommonDAO;
import com.telcel.consultas.cluster.dao.AplicacionDAO;
import com.telcel.consultas.cluster.dao.impl.mapper.AplicacionInfoCompletaMapper;
import com.telcel.consultas.cluster.dao.impl.sql.AplicacionSQL;
import com.telcel.consultas.cluster.domain.Aplicacion;

@Repository("aplicacionDAO")
public class AplicacionDAOImpl extends CommonDAO implements AplicacionDAO {

	public AplicacionDAOImpl() {
	}

	@Override
	public List<Aplicacion> obtenerAplicaciones() {
		List<Aplicacion> listAplicacion = null;

		
		listAplicacion = jdbcTemplate.query(AplicacionSQL.OBTENER_APLICACIONES, new Object[] {}, new AplicacionInfoCompletaMapper());
		return listAplicacion;
	}

	@Override
	public List<Aplicacion> obtenerAplicaciones(String parametro) {
		List<Aplicacion> listAplicacion = null;
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();      
		//Si la condicion es un like en el Query debe concatenarse el simbolo de %
		namedParameters.addValue("idAplicacion",     "%"+parametro+"%");
        namedParameters.addValue("nombreAplicacion", "%"+parametro+"%");
        namedParameters.addValue("nombreDmgr",       "%"+parametro+"%");
        namedParameters.addValue("nombreCluster",    "%"+parametro+"%");
		
		listAplicacion = namedParameterJdbcTemplate.query(AplicacionSQL.OBTENER_APLICACIONES_FILTRO, namedParameters, new AplicacionInfoCompletaMapper());
		return listAplicacion;
	}

}
