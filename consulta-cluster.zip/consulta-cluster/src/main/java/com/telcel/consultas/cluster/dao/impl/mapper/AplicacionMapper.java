package com.telcel.consultas.cluster.dao.impl.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telcel.consultas.cluster.domain.Aplicacion;

public class AplicacionMapper implements RowMapper<Aplicacion> {

	@Override
	public Aplicacion mapRow(ResultSet rs, int arg1) throws SQLException {
		Aplicacion aplicacion = new Aplicacion();
		
		aplicacion.setIdAplicacion(rs.getInt("id_aplicacion"));
		aplicacion.setDescripcion(rs.getString("descripcion")!=null?rs.getString("descripcion"):"");
		aplicacion.setEstatus(rs.getInt("estatus"));
		aplicacion.setNombre(rs.getString("nombre")!=null?rs.getString("nombre"):"");
		aplicacion.setPrioridad(rs.getInt("prioridad"));
		aplicacion.setUrlPruebas(rs.getString("url_pruebas")!=null?rs.getString("url_pruebas"):"");
		aplicacion.setVirtualhost(rs.getString("virtualhost")!=null?rs.getString("virtualhost"):"");		
		return aplicacion;
	}

}
