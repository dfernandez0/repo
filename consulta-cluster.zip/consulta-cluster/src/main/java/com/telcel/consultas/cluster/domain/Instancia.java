package com.telcel.consultas.cluster.domain;

public class Instancia {

	private Integer idInstancia;
	private String  puerto;
	private String  nodo;
	private String  nombreinstan;
	private String  rutaLogs;
	private Integer estatus;
	private Cluster cluster;
	private Servidor servidor;
	
	public Integer getIdInstancia() {
		return idInstancia;
	}
	public void setIdInstancia(Integer idInstancia) {
		this.idInstancia = idInstancia;
	}
	public String getPuerto() {
		return puerto;
	}
	public void setPuerto(String puerto) {
		this.puerto = puerto;
	}
	public String getNodo() {
		return nodo;
	}
	public void setNodo(String nodo) {
		this.nodo = nodo;
	}
	public String getNombreinstan() {
		return nombreinstan;
	}
	public void setNombreinstan(String nombreinstan) {
		this.nombreinstan = nombreinstan;
	}
	public String getRutaLogs() {
		return rutaLogs;
	}
	public void setRutaLogs(String rutaLogs) {
		this.rutaLogs = rutaLogs;
	}
	public Integer getEstatus() {
		return estatus;
	}
	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	public Cluster getCluster() {
		return cluster;
	}
	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}
	public Servidor getServidor() {
		return servidor;
	}
	public void setServidor(Servidor servidor) {
		this.servidor = servidor;
	}
	@Override
	public String toString() {
		return "Instancia [idInstancia=" + idInstancia + ", puerto=" + puerto + ", nodo=" + nodo + ", nombreinstan="
				+ nombreinstan + ", rutaLogs=" + rutaLogs + ", estatus=" + estatus + ", cluster=" + cluster
				+ ", servidor=" + servidor + "]";
	}

	
}
