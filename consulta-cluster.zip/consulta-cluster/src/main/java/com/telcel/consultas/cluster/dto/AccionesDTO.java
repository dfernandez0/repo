package com.telcel.consultas.cluster.dto;

public class AccionesDTO {

	private boolean mostrarDetalle;
	private boolean mostrarNuevo;
	private boolean mostrarEliminar;
	private boolean mostrarLista;
	private String textoBuscar;

	public boolean isMostrarDetalle() {
		return mostrarDetalle;
	}

	public void setMostrarDetalle(boolean mostrarDetalle) {
		this.mostrarDetalle = mostrarDetalle;
	}

	public boolean isMostrarNuevo() {
		return mostrarNuevo;
	}

	public void setMostrarNuevo(boolean mostrarNuevo) {
		this.mostrarNuevo = mostrarNuevo;
	}

	public boolean isMostrarEliminar() {
		return mostrarEliminar;
	}

	public void setMostrarEliminar(boolean mostrarEliminar) {
		this.mostrarEliminar = mostrarEliminar;
	}

	public boolean isMostrarLista() {
		return mostrarLista;
	}

	public void setMostrarLista(boolean mostrarLista) {
		this.mostrarLista = mostrarLista;
	}

	public String getTextoBuscar() {
		return textoBuscar;
	}

	public void setTextoBuscar(String textoBuscar) {
		this.textoBuscar = textoBuscar;
	}

	@Override
	public String toString() {
		return "AccionesDTO [mostrarDetalle=" + mostrarDetalle + ", mostrarNuevo=" + mostrarNuevo + ", mostrarEliminar="
				+ mostrarEliminar + ", mostrarLista=" + mostrarLista + ", textoBuscar=" + textoBuscar + "]";
	}
}
