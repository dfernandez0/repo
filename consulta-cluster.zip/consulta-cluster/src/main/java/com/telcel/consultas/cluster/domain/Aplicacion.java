package com.telcel.consultas.cluster.domain;

import java.io.Serializable;

public class Aplicacion implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -233771975219308680L;
	private Integer idAplicacion;
	private String  nombre;
	private String  virtualhost;
	private String  urlPruebas;
	private String  descripcion;
	private Integer prioridad;
	private Integer estatus;
	private Cluster cluster;
	private Dmgr dmgr;
	private Instancia instancia;
	private Area area;
	
	public Integer getIdAplicacion() {
		return idAplicacion;
	}
	public void setIdAplicacion(Integer idAplicacion) {
		this.idAplicacion = idAplicacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getVirtualhost() {
		return virtualhost;
	}
	public void setVirtualhost(String virtualhost) {
		this.virtualhost = virtualhost;
	}
	public String getUrlPruebas() {
		return urlPruebas;
	}
	public void setUrlPruebas(String urlPruebas) {
		this.urlPruebas = urlPruebas;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public Integer getEstatus() {
		return estatus;
	}
	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}
	public Cluster getCluster() {
		return cluster;
	}
	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}
	public Instancia getInstancia() {
		return instancia;
	}
	public void setInstancia(Instancia instancia) {
		this.instancia = instancia;
	}
	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	public Dmgr getDmgr() {
		return dmgr;
	}
	public void setDmgr(Dmgr dmgr) {
		this.dmgr = dmgr;
	}
	@Override
	public String toString() {
		return "Aplicacion [idAplicacion=" + idAplicacion + ", nombre=" + nombre + ", virtualhost=" + virtualhost
				+ ", urlPruebas=" + urlPruebas + ", descripcion=" + descripcion + ", prioridad=" + prioridad
				+ ", estatus=" + estatus + ", cluster=" + cluster + ", dmgr=" + dmgr + ", instancia=" + instancia
				+ ", area=" + area + "]";
	}
	
}
