package com.telcel.consultas.cluster.services;

import java.util.List;

import com.telcel.consultas.cluster.domain.Usuario;

public interface UsuarioService {

	public List<Usuario> obtenerUsuarios();
	public List<Usuario> buscarUsuarioFiltrado(String parametro);
	public void guardarUsuario(Usuario usuario);
	public void  eliminarUsuario(Integer idUsuario);
	public Usuario validarUsuario(Usuario usuario);
}
