package com.telcel.consultas.cluster.domain;

import java.io.Serializable;

public class Area implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3628237453295327595L;
	private Integer idArea;
	private Integer idGerencia;
	private String nombre;
	private String guardia;
	private String comentario;
	private Integer accesoSistema;
	public Integer getIdArea() {
		return idArea;
	}
	public void setIdArea(Integer idArea) {
		this.idArea = idArea;
	}
	public Integer getIdGerencia() {
		return idGerencia;
	}
	public void setIdGerencia(Integer idGerencia) {
		this.idGerencia = idGerencia;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getGuardia() {
		return guardia;
	}
	public void setGuardia(String guardia) {
		this.guardia = guardia;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public Integer getAccesoSistema() {
		return accesoSistema;
	}
	public void setAccesoSistema(Integer accesoSistema) {
		this.accesoSistema = accesoSistema;
	}
	@Override
	public String toString() {
		return "Area [idArea=" + idArea + ", idGerencia=" + idGerencia + ", nombre=" + nombre + ", guardia=" + guardia
				+ ", comentario=" + comentario + ", acceso_sistema=" + accesoSistema + "]";
	}
	
	

}
