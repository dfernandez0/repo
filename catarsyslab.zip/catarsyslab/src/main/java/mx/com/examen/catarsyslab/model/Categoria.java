package mx.com.examen.catarsyslab.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="tblc_categoria")
@NamedQuery(name="Categoria.findAll", query="SELECT c FROM Categoria c")
public class Categoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_categoria")
	private int idCategoria;

	private byte activo;

	private String descripcion;

	private String nombre;

	//bi-directional many-to-one association to ProductoCategoria
	@OneToMany(mappedBy="categorias", fetch=FetchType.EAGER)
	private List<ProductoCategoria> listaProductoCategorias;

	public Categoria() {
	}

	public int getIdCategoria() {
		return this.idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public byte getActivo() {
		return this.activo;
	}

	public void setActivo(byte activo) {
		this.activo = activo;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<ProductoCategoria> getListaProductoCategorias() {
		return listaProductoCategorias;
	}

	public void setListaProductoCategorias(List<ProductoCategoria> listaProductoCategorias) {
		this.listaProductoCategorias = listaProductoCategorias;
	}

	public ProductoCategoria addListaProductoCategorias(ProductoCategoria listaProductoCategorias) {
		getListaProductoCategorias().add(listaProductoCategorias);
		listaProductoCategorias.setCategorias(this);
		return listaProductoCategorias;
	}

	public ProductoCategoria removeListaProductoCategorias(ProductoCategoria listaProductoCategorias) {
		getListaProductoCategorias().remove(listaProductoCategorias);
		listaProductoCategorias.setCategorias(null);
		return listaProductoCategorias;
	}
}