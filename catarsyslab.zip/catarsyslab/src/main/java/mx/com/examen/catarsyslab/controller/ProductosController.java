package mx.com.examen.catarsyslab.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import mx.com.examen.catarsyslab.model.Productos;
import mx.com.examen.catarsyslab.model.Student;
import mx.com.examen.catarsyslab.services.ProductosService;
import mx.com.examen.catarsyslab.services.StudentService;

public class ProductosController {
	@Autowired
	private ProductosService productosService;

	@RequestMapping(value = "/enroll", method = RequestMethod.GET)
	public String newRegistration(ModelMap model) {
		Productos productos = new Productos();
		model.addAttribute("producto", productos);
		return "enroll";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveRegistration(@Valid Productos productos, BindingResult result, ModelMap model,
			RedirectAttributes redirectAttributes) {
		if (result.hasErrors()) {
			System.out.println("has errors");
			return "enroll";
		}
		productosService.guardar(productos);
		return "redirect:/viewstudents";
	}

	@RequestMapping(value = "/viewstudents")
	public ModelAndView getAll() {
		List<Productos> list = productosService.getProductos();
		return new ModelAndView("viewstudents", "list", list);
	}

	@RequestMapping(value = "/editstudent/{id}")
	public String edit(@PathVariable int id, ModelMap model) {
		Productos productos = productosService.encontrar(id);
		model.addAttribute("producto", productos);
		return "editstudent";
	}

	@RequestMapping(value = "/editsave", method = RequestMethod.POST)
	public ModelAndView editsave(@ModelAttribute("student") Student p) {

		Productos Producto = productosService.encontrar(p.getId());
		/*
		student.setFirstName(p.getFirstName());
		student.setLastName(p.getLastName());
		student.setCountry(p.getCountry());
		student.setEmail(p.getEmail());
		student.setSection(p.getSection());
		student.setSex(p.getSex());
		*/
		productosService.guardar(Producto);
		return new ModelAndView("redirect:/viewstudents");
	}

	@RequestMapping(value = "/deletestudent/{id}", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable int id) {
		Productos producto = productosService.encontrar(id);
		productosService.eliminar(producto.getIdProducto());
		return new ModelAndView("redirect:/viewstudents");
	}

	@ModelAttribute("sections")
	public List<String> intializeSections() {
		List<String> sections = new ArrayList<String>();
		sections.add("Graduate");
		sections.add("Post Graduate");
		sections.add("Reasearch");
		return sections;
	}
}
