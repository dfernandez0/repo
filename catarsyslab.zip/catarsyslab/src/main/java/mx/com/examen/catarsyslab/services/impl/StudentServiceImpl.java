package mx.com.examen.catarsyslab.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.examen.catarsyslab.model.Student;
import mx.com.examen.catarsyslab.repository.StudentRepository;
import mx.com.examen.catarsyslab.services.StudentService;

@Service("studentService")
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public List<Student> getStudents() {
		List<Student> lista =(List<Student>) this.studentRepository.findAll();
		return lista;
	}

	@Override
	public void guardar(Student student) {
		this.studentRepository.save(student);
	}

	@Override
	public void eliminar(Integer id) {
		this.studentRepository.deleteById(id);
	}
	
	@Override
	public Student encontrar(Integer id) {
		return this.studentRepository.getOne(id);
	}
}
