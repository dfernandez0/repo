package mx.com.examen.catarsyslab.services;

import java.util.List;

import mx.com.examen.catarsyslab.model.Productos;

public interface ProductosService {
	List<Productos> getProductos();
	void guardar(Productos productos);
	void eliminar(Integer id);
	Productos encontrar(Integer id);
}
