package mx.com.examen.catarsyslab.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="tblc_producto_categoria")
@NamedQuery(name="ProductoCategoria.findAll", query="SELECT p FROM ProductoCategoria p")
public class ProductoCategoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_producto_categoria")
	private int idProductoCategoria;

	//bi-directional many-to-one association to Categoria
	@ManyToOne
	@JoinColumn(name="id_categoria")
	private Categoria categorias;

	//bi-directional many-to-one association to Productos
	@ManyToOne
	@JoinColumn(name="id_producto")
	private Productos productos;

	public ProductoCategoria() {
	}

	public int getIdProductoCategoria() {
		return this.idProductoCategoria;
	}

	public void setIdProductoCategoria(int idProductoCategoria) {
		this.idProductoCategoria = idProductoCategoria;
	}

	public Categoria getCategorias() {
		return categorias;
	}

	public void setCategorias(Categoria categorias) {
		this.categorias = categorias;
	}

	public Productos getProductos() {
		return productos;
	}

	public void setProductos(Productos productos) {
		this.productos = productos;
	}
}