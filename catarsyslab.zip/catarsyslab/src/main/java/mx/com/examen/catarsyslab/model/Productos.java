package mx.com.examen.catarsyslab.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="tblt_productos")
@NamedQuery(name="Productos.findAll", query="SELECT p FROM Productos p")
public class Productos implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_producto")
	private int idProducto;

	private byte activo;

	private String clave;

	private String descripcion;

	private String nombre;

	@Column(name="precio_unitario")
	private double precioUnitario;

	private int stock;

	//bi-directional many-to-one association to ProductoCategoria
	@OneToMany(mappedBy="productos", fetch=FetchType.EAGER)
	private List<ProductoCategoria> listaProductoCategorias;

	/*
	//bi-directional many-to-one association to VentasDetalle
	@OneToMany(mappedBy="productos", fetch=FetchType.EAGER)
	private List<VentasDetalle> listaVentaDetalles;
	*/
	public Productos() {
	}

	public int getIdProducto() {
		return this.idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public byte getActivo() {
		return this.activo;
	}

	public void setActivo(byte activo) {
		this.activo = activo;
	}

	public String getClave() {
		return this.clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecioUnitario() {
		return this.precioUnitario;
	}

	public void setPrecioUnitario(double precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public int getStock() {
		return this.stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public List<ProductoCategoria> getListaProductoCategorias() {
		return listaProductoCategorias;
	}

	public void setListaProductoCategorias(List<ProductoCategoria> listaProductoCategorias) {
		this.listaProductoCategorias = listaProductoCategorias;
	}

	public ProductoCategoria addListaProductoCategorias(ProductoCategoria listaProductoCategorias) {
		getListaProductoCategorias().add(listaProductoCategorias);
		listaProductoCategorias.setProductos(this);
		return listaProductoCategorias;
	}

	public ProductoCategoria removeListaProductoCategorias(ProductoCategoria listaProductoCategorias) {
		getListaProductoCategorias().remove(listaProductoCategorias);
		listaProductoCategorias.setProductos(null);
		return listaProductoCategorias;
	}
/*
	public List<VentasDetalle> getListaVentaDetalles() {
		return listaVentaDetalles;
	}

	public void setListaVentaDetalles(List<VentasDetalle> listaVentaDetalles) {
		this.listaVentaDetalles = listaVentaDetalles;
	}

	public VentasDetalle addListaVentaDetalles(VentasDetalle listaVentaDetalles) {
		getListaVentaDetalles().add(listaVentaDetalles);
		listaVentaDetalles.setProductos(this);
		return listaVentaDetalles;
	}

	public VentasDetalle removeListaVentaDetalles(VentasDetalle listaVentaDetalles) {
		getListaVentaDetalles().remove(listaVentaDetalles);
		listaVentaDetalles.setProductos(null);
		return listaVentaDetalles;
	}*/
}