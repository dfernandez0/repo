package mx.com.examen.catarsyslab.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.com.examen.catarsyslab.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
