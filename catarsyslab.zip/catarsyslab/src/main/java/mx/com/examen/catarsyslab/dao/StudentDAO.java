package mx.com.examen.catarsyslab.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.examen.catarsyslab.model.Student;
import mx.com.examen.catarsyslab.repository.StudentRepository;

@Service
public class StudentDAO {
	@Autowired
	StudentRepository studentRepository;

	public Student save(Student std) {
		return studentRepository.save(std);
	}

	public List<Student> findAll() {
		return studentRepository.findAll();
	}

	public Student findOne(Integer id) {
		return studentRepository.getOne(id);
	}

	public void delete(Student std) {
		studentRepository.delete(std);
	}

}
