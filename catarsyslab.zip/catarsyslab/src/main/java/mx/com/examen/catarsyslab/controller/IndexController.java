package mx.com.examen.catarsyslab.controller;

import org.springframework.stereotype.Controller;

@Controller
public class IndexController {

}
