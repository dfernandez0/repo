package mx.com.examen.catarsyslab.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="tblt_venta_detalle")
@NamedQuery(name="VentasDetalle.findAll", query="SELECT v FROM VentasDetalle v")
public class VentasDetalle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_venta_detalle")
	private int idVentaDetalle;

	private int cantidad;

	private double precio;

	//bi-directional many-to-one association to Ventas
	@ManyToOne
	@JoinColumn(name="id_venta")
	private Ventas ventas;

	//bi-directional many-to-one association to Productos
	@ManyToOne
	@JoinColumn(name="id_producto")
	private Productos productos;

	public VentasDetalle() {
	}

	public int getIdVentaDetalle() {
		return this.idVentaDetalle;
	}

	public void setIdVentaDetalle(int idVentaDetalle) {
		this.idVentaDetalle = idVentaDetalle;
	}

	public int getCantidad() {
		return this.cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Ventas getVentas() {
		return ventas;
	}

	public void setVentas(Ventas ventas) {
		this.ventas = ventas;
	}

	public Productos getProductos() {
		return productos;
	}

	public void setProductos(Productos productos) {
		this.productos = productos;
	}
}