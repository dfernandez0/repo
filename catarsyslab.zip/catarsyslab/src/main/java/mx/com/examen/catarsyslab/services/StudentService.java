package mx.com.examen.catarsyslab.services;

import java.util.List;

import mx.com.examen.catarsyslab.model.Student;

public interface StudentService {
	List<Student> getStudents();
	void guardar(Student student);
	void eliminar(Integer id);
	Student encontrar(Integer id);
}
