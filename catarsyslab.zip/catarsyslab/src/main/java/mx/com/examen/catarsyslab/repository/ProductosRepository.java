package mx.com.examen.catarsyslab.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.com.examen.catarsyslab.model.Productos;

public interface ProductosRepository extends JpaRepository<Productos, Integer>{

}
