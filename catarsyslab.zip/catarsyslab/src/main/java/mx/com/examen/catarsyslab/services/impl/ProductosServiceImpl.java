package mx.com.examen.catarsyslab.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.examen.catarsyslab.model.Productos;
import mx.com.examen.catarsyslab.repository.ProductosRepository;
import mx.com.examen.catarsyslab.services.ProductosService;

@Service("productosService")
public class ProductosServiceImpl implements ProductosService {
	@Autowired
	private ProductosRepository productosRepository;
	
	@Override
	public List<Productos> getProductos() {
		List<Productos> lista =(List<Productos>) this.productosRepository.findAll();
		return lista;
	}

	@Override
	public void guardar(Productos productos) {
		this.productosRepository.save(productos);
	}

	@Override
	public void eliminar(Integer id) {
		this.productosRepository.deleteById(id);
	}
	
	@Override
	public Productos encontrar(Integer id) {
		return this.productosRepository.getOne(id);
	}
}
