package mx.com.examen.catarsyslab.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="tblt_ventas")
@NamedQuery(name="Ventas.findAll", query="SELECT v FROM Ventas v")
public class Ventas implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_venta")
	private int idVenta;

	@Column(name="cupo_descuento")
	private int cupoDescuento;

	private String descripcion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Column(name="generar_factura")
	private byte generarFactura;

	//bi-directional many-to-one association to VentasDetalle
	@OneToMany(mappedBy="ventas", fetch=FetchType.EAGER)
	private List<VentasDetalle> listaVentaDetalles;

	public Ventas() {
	}

	public int getIdVenta() {
		return this.idVenta;
	}

	public void setIdVenta(int idVenta) {
		this.idVenta = idVenta;
	}

	public int getCupoDescuento() {
		return this.cupoDescuento;
	}

	public void setCupoDescuento(int cupoDescuento) {
		this.cupoDescuento = cupoDescuento;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public byte getGenerarFactura() {
		return this.generarFactura;
	}

	public void setGenerarFactura(byte generarFactura) {
		this.generarFactura = generarFactura;
	}

	public List<VentasDetalle> getListaVentaDetalles() {
		return listaVentaDetalles;
	}

	public void setListaVentaDetalles(List<VentasDetalle> listaVentaDetalles) {
		this.listaVentaDetalles = listaVentaDetalles;
	}

	public VentasDetalle addListaVentaDetalles(VentasDetalle listaVentaDetalles) {
		getListaVentaDetalles().add(listaVentaDetalles);
		listaVentaDetalles.setVentas(this);
		return listaVentaDetalles;
	}

	public VentasDetalle removeListaVentaDetalles(VentasDetalle listaVentaDetalles) {
		getListaVentaDetalles().remove(listaVentaDetalles);
		listaVentaDetalles.setVentas(null);
		return listaVentaDetalles;
	}
	
}