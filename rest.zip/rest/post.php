<?php
include('Requests.php');
include('Contantes.php');
Requests::register_autoloader();
$headers = array(/*'Content-type' => 'application/json','Accept'=>'application/json','cache-control'=>'no-cache'*/);
$data = array('Token'=>'QAZXSWEDC',
    'Operacion'=>array('PermisoComprador' => 'G/162/LPD/2004',
            'PermisoVendedor' => 'G/020/LPA/2010',
            'Cantidad' => 150.0,
            'FechaCompra' => '10/10/2018',
            'PrecioAcordado' => 20.0,
            'Traspaso' => false,
            'EntregaParcial' => false,
            'Importacion' => 0,
            'TipoCambio' => null,
            'IdPais' => null,
            'IdPermisoImportacion' => null,
            'IdMedio' => null,
            'RazonSocialImportacion' => null,
            'IdArancel' => null,
            'CompraExterno' => '12345678908'));
$request = Requests::post('https://siretrac-serviciosweb-qa.azurewebsites.net/api/Compras/RegistrarCompra/', $headers, $data);
echo $request->body;
var_dump($request);

?>