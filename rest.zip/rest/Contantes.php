<?php
class Contantes{
    const URL = 'https://siretrac-serviciosweb-qa.azurewebsites.net';
    const MOD_COMPRAS = '/api/Compras';
    const MOD_ENTREGAS = '/api/RegistroEntrega';
    const MOD_PRECIOS = '/api/Precios';
    const MOD_VENTA = '/api/Venta';
}

